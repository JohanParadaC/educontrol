// backend/__tests__/usuarios.validation.test.js
const request = require('supertest');
const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const dbConnection = require('../config/db');

let app;
let mongod;
let token;

beforeAll(async () => {
  mongod = await MongoMemoryServer.create();
  process.env.MONGO_URI = mongod.getUri();
  process.env.JWT_SECRET = 'test-secret';
  process.env.NODE_ENV = 'test';

  app = require('../app');
  await dbConnection();

  // Seed admin y login para obtener token
  await request(app).post('/api/admin/seed-admin').send({
    correo: 'admin@educontrol.com',
    password: 'admin123'
  });
  const login = await request(app).post('/api/auth/login').send({
    correo: 'admin@educontrol.com',
    contraseña: 'admin123'
  });
  token = login.body.token;
});

afterAll(async () => {
  await mongoose.connection.close();
  if (mongod) await mongod.stop();
});

describe('Usuarios validations', () => {
  it('POST /api/usuarios -> 400 si faltan campos', async () => {
    const res = await request(app)
      .post('/api/usuarios')
      .set('Authorization', `Bearer ${token}`)
      .send({ correo: 'nuevo@edu.com', contraseña: 'secret' }); // falta nombre y rol
    expect(res.status).toBe(400);
    expect(res.body).toHaveProperty('errors');
  });

  it('POST /api/usuarios -> 201/200 crea usuario válido', async () => {
    const res = await request(app)
      .post('/api/usuarios')
      .set('Authorization', `Bearer ${token}`)
      .send({
        nombre: 'Nuevo',
        correo: 'nuevo@edu.com',
        contraseña: 'secret',
        rol: 'estudiante'
      });
    expect([200, 201]).toContain(res.status);
    expect(res.body).toHaveProperty('usuario');
  });
});