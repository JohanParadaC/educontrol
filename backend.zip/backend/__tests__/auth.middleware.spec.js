const request = require('supertest');
const app = require('../app');
const { createUserAndLogin } = require('./helpers');

describe('Auth middleware / roleCheck', () => {
  test('401 si no envía token (ruta protegida real)', async () => {
    // Sabemos que /api/cursos requiere auth → perfecto para 401
    await request(app).get('/api/cursos').expect(401);
  });

  test('403 si rol no autorizado (estudiante intenta acción de admin)', async () => {
    const { token } = await createUserAndLogin('estudiante');
    const res = await request(app)
      .post('/api/cursos') // crear curso debería ser sólo admin
      .set('Authorization', `Bearer ${token}`)
      .send({ titulo: 'Prohibido', descripcion: '...', cupo: 10 });

    expect([401, 403]).toContain(res.status); // según tu middleware puede ser 401/403
  });
});