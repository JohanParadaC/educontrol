// backend/__tests__/auth.validation.test.js
const request = require('supertest');
const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const dbConnection = require('../config/db');

let app;
let mongod;

beforeAll(async () => {
  mongod = await MongoMemoryServer.create();
  process.env.MONGO_URI = mongod.getUri();
  process.env.JWT_SECRET = 'test-secret';
  process.env.NODE_ENV = 'test';

  // requiere app DESPUÉS de setear envs
  app = require('../app');
  await dbConnection();
});

afterAll(async () => {
  await mongoose.connection.close();
  if (mongod) await mongod.stop();
});

describe('Auth validations', () => {
  it('POST /api/auth/login -> 400 si faltan campos', async () => {
    const res = await request(app).post('/api/auth/login').send({});
    expect(res.status).toBe(400);
  });

  it('POST /api/auth/login -> 400/401 credenciales inválidas', async () => {
    // seed admin con password conocido
    await request(app).post('/api/admin/seed-admin').send({
      correo: 'admin@educontrol.com',
      password: 'admin123'
    });
    // intento con pass incorrecto
    const res = await request(app).post('/api/auth/login').send({
      correo: 'admin@educontrol.com',
      contraseña: 'badpass'
    });
    expect([400, 401]).toContain(res.status);
  });

  it('POST /api/auth/login -> 200 con credenciales correctas', async () => {
    const res = await request(app).post('/api/auth/login').send({
      correo: 'admin@educontrol.com',
      contraseña: 'admin123'
    });
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('token');
    expect(res.body).toHaveProperty('usuario');
  });
});