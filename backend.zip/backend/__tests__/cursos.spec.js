const request = require('supertest');
const app = require('../app');
const { createUserAndLogin } = require('./helpers');

describe('Cursos', () => {
  let adminToken;
  beforeAll(async () => {
    ({ token: adminToken } = await createUserAndLogin('admin'));
  });

  test('GET /api/cursos lista (requiere token)', async () => {
    const { status, body } = await request(app)
      .get('/api/cursos')
      .set('Authorization', `Bearer ${adminToken}`);
    expect(status).toBe(200);
    expect(Array.isArray(body.cursos ?? body)).toBe(true);
  });

  test('GET /api/cursos/:id -> 400 con id inválido (con token)', async () => {
    await request(app)
      .get('/api/cursos/xxx')
      .set('Authorization', `Bearer ${adminToken}`)
      .expect(400);
  });

  test('POST /api/cursos crea curso (201/200) [admin]', async () => {
    const res = await request(app)
      .post('/api/cursos')
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ titulo: 'Angular Básico', descripcion: 'Intro', cupo: 40 });

    expect([200, 201]).toContain(res.status);
  });

  test('PUT /api/cursos/:id -> 404 si no existe [admin]', async () => {
    const fakeId = '66a7c1b2a1a1a1a1a1a1a1a1'; // formato ObjectId
    const res = await request(app)
      .put(`/api/cursos/${fakeId}`)
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ titulo: 'Nuevo' });
    expect([404, 400]).toContain(res.status);
  });
});