/** @type {import('jest').Config} */
module.exports = {
  testEnvironment: 'node',
  // Corre después de cargar Jest (ideal para DB en memoria, hooks globales, etc.)
  setupFilesAfterEnv: ['<rootDir>/jest.setup.js'],

  // Acepta tanto *.spec.js como *.test.js dentro de __tests__/
  testMatch: ['**/__tests__/**/*.(spec|test).js'],

  // Qué archivos cuentan para cobertura
  collectCoverageFrom: [
    'app.js',
    'config/**/*.js',
    'controllers/**/*.js',
    'middlewares/**/*.js',
    'models/**/*.js',
    'routes/**/*.js',
    // excluye tests y utilidades de test
    '!**/__tests__/**',
    '!**/*.test.js',
    '!**/*.spec.js'
  ],

  coverageDirectory: 'coverage',
  coverageReporters: ['text', 'lcov', 'html'],

  // Umbrales mínimos (si no se alcanzan, Jest falla)
  coverageThreshold: {
    global: {
      statements: 80,
      branches: 60,
      functions: 70,
      lines: 80,
    },
  },

  verbose: true,
};